<?
$arModuleVersion = [
    "VERSION" => "1.1.9",
    "VERSION_DATE" => "2025-05-23 12:51:00"
];